import telebot
from telebot import types  # для указание типов
import config

bot = telebot.TeleBot('6478640026:AAF8GlCdT7OIarPr1__0SeR95q070Y1FTLI')


@bot.message_handler(commands=['start'])
def start(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn1 = types.KeyboardButton("Расписание уроков")
    btn2 = types.KeyboardButton("Расписание звонков")
    markup.add(btn1, btn2)
    bot.send_message(message.chat.id,
                     text="Привет, {0.first_name}!".format(
                         message.from_user))
    bot.send_message(message.chat.id, text="Что хочешь узнать?", reply_markup=markup)


@bot.message_handler(content_types=['text'])
def func(message):
    if (message.text == "Расписание звонков"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Первые классы")
        btn2 = types.KeyboardButton("Основное расписание звонков")
        btn5 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1, btn2)
        markup.row(btn5)
        bot.send_message(message.chat.id, text="Выбери категорию:", reply_markup=markup)

    elif (message.text == "Основное расписание звонков"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn5 = types.KeyboardButton("Вернуться назад")
        markup.add(btn5)
        file = open('Timing.jpg', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Первые классы"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn5 = types.KeyboardButton("Вернуться назад")
        markup.add(btn5)
        file = open('расписание для первых классов.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)



    elif (message.text == "Расписание уроков"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Младшая школа")
        btn2 = types.KeyboardButton("Средняя школа")
        btn3 = types.KeyboardButton("Старшая школа")
        btn5 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1, btn2, btn3, btn5)
        bot.send_message(message.chat.id, text="Выбери категорию:", reply_markup=markup)

    elif (message.text == "Младшая школа"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("1 класс")
        btn2 = types.KeyboardButton("2 класс")
        btn3 = types.KeyboardButton("3 класс")
        btn4 = types.KeyboardButton("4 класс")
        markup.row(btn1, btn2, btn3, btn4)
        btn5 = types.KeyboardButton("Вернуться назад")
        markup.row(btn5)
        bot.send_message(message.chat.id, text="Выбери класс:", reply_markup=markup)

    elif (message.text == "1 класс"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("1А")
        btn2 = types.KeyboardButton("1Б")
        btn3 = types.KeyboardButton("1В")
        btn4 = types.KeyboardButton("1Г")
        btn5 = types.KeyboardButton("1Д")
        btn6 = types.KeyboardButton("1.1Е")
        btn7 = types.KeyboardButton("1.1Ж")
        markup.row(btn1, btn2)
        markup.row(btn3, btn4, btn5)
        markup.row(btn6, btn7)
        btn5 = types.KeyboardButton("Вернуться назад")
        markup.row(btn5)
        bot.send_message(message.chat.id, text="Выбери букву:", reply_markup=markup)

    elif (message.text == "1А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 1А")
        btn2 = types.KeyboardButton("Вторник 1А")
        btn3 = types.KeyboardButton("Среда 1А")
        btn4 = types.KeyboardButton("Четверг 1А")
        btn5 = types.KeyboardButton("Пятница 1А")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 1А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.InlineKeyboardButton("Вернуться назад", callback_data='delete')
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-А класса на понедельник:", reply_markup=markup)
        file = open('понедельник 1А.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 1А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-А класса на вторник:", reply_markup=markup)
        file = open('вторник 1А.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 1А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-А класса на среду:", reply_markup=markup)
        file = open('среда 1А.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 1А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-А класса на четверг:", reply_markup=markup)
        file = open('четверг 1А.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 1А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-А класса на пятницу:", reply_markup=markup)
        file = open('пятница 1А.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "1Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 1Б")
        btn2 = types.KeyboardButton("Вторник 1Б")
        btn3 = types.KeyboardButton("Среда 1Б")
        btn4 = types.KeyboardButton("Четверг 1Б")
        btn5 = types.KeyboardButton("Пятница 1Б")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 1Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-Б класса на понедельник:", reply_markup=markup)
        file = open('понедельник 1Б.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 1Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-Б класса на вторник:", reply_markup=markup)
        file = open('вторник 1Б.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 1Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-Б класса на среду:", reply_markup=markup)
        file = open('среда 1Б.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 1Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-Б класса на четверг:", reply_markup=markup)
        file = open('четверг 1Б.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 1Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-Б класса на пятницу:", reply_markup=markup)
        file = open('пятница 1Б.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "1В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 1В")
        btn2 = types.KeyboardButton("Вторник 1В")
        btn3 = types.KeyboardButton("Среда 1В")
        btn4 = types.KeyboardButton("Четверг 1В")
        btn5 = types.KeyboardButton("Пятница 1В")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 1В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-В класса на понедельник:", reply_markup=markup)
        file = open('понедельник 1В.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 1В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-В класса на вторник:", reply_markup=markup)
        file = open('вторник 1В.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 1В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-В класса на среду:", reply_markup=markup)
        file = open('среда 1В.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 1В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-В класса на четверг:", reply_markup=markup)
        file = open('./четверг 1В.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 1В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-В класса на пятницу:", reply_markup=markup)
        file = open('пятница 1В.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)


    elif (message.text == "1Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 1Г")
        btn2 = types.KeyboardButton("Вторник 1Г")
        btn3 = types.KeyboardButton("Среда 1Г")
        btn4 = types.KeyboardButton("Четверг 1Г")
        btn5 = types.KeyboardButton("Пятница 1Г")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 1Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-Г класса на понедельник:", reply_markup=markup)
        file = open('понедельник 1Г.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 1Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-Г класса на вторник:", reply_markup=markup)
        file = open('вторник 1Г.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 1Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-Г класса на среду:", reply_markup=markup)
        file = open('среда 1Г.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 1Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-Г класса на четверг:", reply_markup=markup)
        file = open('четверг 1Г.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 1Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-Г класса на пятницу:", reply_markup=markup)
        file = open('пятница 1Г.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "1Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 1Д")
        btn2 = types.KeyboardButton("Вторник 1Д")
        btn3 = types.KeyboardButton("Среда 1Д")
        btn4 = types.KeyboardButton("Четверг 1Д")
        btn5 = types.KeyboardButton("Пятница 1Д")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 1Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-Д класса на понедельник:", reply_markup=markup)
        file = open('понедельник 1Д.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 1Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-Д класса на вторник:", reply_markup=markup)
        file = open('вторник 1Д.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 1Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-Д класса на среду:", reply_markup=markup)
        file = open('среда 1Д.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 1Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-Д класса на четверг:", reply_markup=markup)
        file = open('четверг 1Д.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 1Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1-Д класса на пятницу:", reply_markup=markup)
        file = open('пятница 1Д.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "1.1Е"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 1.1Е")
        btn2 = types.KeyboardButton("Вторник 1.1Е")
        btn3 = types.KeyboardButton("Среда 1.1Е")
        btn4 = types.KeyboardButton("Четверг 1.1Е")
        btn5 = types.KeyboardButton("Пятница 1.1Е")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 1.1Е"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1.1-Е класса на понедельник:", reply_markup=markup)
        file = open('понедельник 1Е.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 1.1Е"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1.1-Е класса на вторник:", reply_markup=markup)
        file = open('вторник 1Е.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 1.1Е"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1.1-Е класса на среду:", reply_markup=markup)
        file = open('среда 1Е.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 1.1Е"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1.1-Е класса на четверг:", reply_markup=markup)
        file = open('четверг 1Е.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 1.1Е"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1.1-Е класса на пятницу:", reply_markup=markup)
        file = open('пятница 1Е.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "1.1Ж"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 1.1Ж")
        btn2 = types.KeyboardButton("Вторник 1.1Ж")
        btn3 = types.KeyboardButton("Среда 1.1Ж")
        btn4 = types.KeyboardButton("Четверг 1.1Ж")
        btn5 = types.KeyboardButton("Пятница 1.1Ж")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 1.1Ж"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1.1-Ж класса на понедельник:", reply_markup=markup)
        file = open('понедельник 1Ж.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 1.1Ж"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1.1-Ж класса на вторник:", reply_markup=markup)
        file = open('вторник 1Ж.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 1.1Ж"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1.1-Ж класса на среду:", reply_markup=markup)
        file = open('среда 1Ж.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 1.1Ж"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1.1-Ж класса на четверг:", reply_markup=markup)
        file = open('четверг 1Ж.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 1.1Ж"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 1.1-Ж класса на пятницу:", reply_markup=markup)
        file = open('пятница 1Ж.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)


    elif (message.text == "2 класс"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("2А")
        btn2 = types.KeyboardButton("2Б")
        btn3 = types.KeyboardButton("2В")
        btn4 = types.KeyboardButton("2Г")
        btn5 = types.KeyboardButton("2Д")
        btn6 = types.KeyboardButton("2Е")
        markup.row(btn1, btn2, btn3)
        markup.row(btn4, btn5, btn6)
        btn5 = types.KeyboardButton("Вернуться назад")
        markup.row(btn5)
        bot.send_message(message.chat.id, text="Выбери букву:", reply_markup=markup)

    elif (message.text == "2А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 2А")
        btn2 = types.KeyboardButton("Вторник 2А")
        btn3 = types.KeyboardButton("Среда 2А")
        btn4 = types.KeyboardButton("Четверг 2А")
        btn5 = types.KeyboardButton("Пятница 2А")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 2А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-А класса на понедельник:", reply_markup=markup)
        file = open('понедельник 2А.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 2А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-А класса на вторник:", reply_markup=markup)
        file = open('вторник 2А.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 2А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-А класса на среду:", reply_markup=markup)
        file = open('среда 2А.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 2А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-А класса на четверг:", reply_markup=markup)
        file = open('четверг 2А.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 2А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-А класса на пятницу:", reply_markup=markup)
        file = open('пятница 2А.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "2Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 2Б")
        btn2 = types.KeyboardButton("Вторник 2Б")
        btn3 = types.KeyboardButton("Среда 2Б")
        btn4 = types.KeyboardButton("Четверг 2Б")
        btn5 = types.KeyboardButton("Пятница 2Б")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 2Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-Б класса на понедельник:", reply_markup=markup)
        file = open('понедельник 2Б.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 2Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-Б класса на вторник:", reply_markup=markup)
        file = open('вторник 2Б.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 2Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-Б класса на среду:", reply_markup=markup)
        file = open('среда 2Б.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 2Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-Б класса на четверг:", reply_markup=markup)
        file = open('четверг 2Б.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 2Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-Б класса на пятницу:", reply_markup=markup)
        file = open('пятница 2Б.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "2В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 2В")
        btn2 = types.KeyboardButton("Вторник 2В")
        btn3 = types.KeyboardButton("Среда 2В")
        btn4 = types.KeyboardButton("Четверг 2В")
        btn5 = types.KeyboardButton("Пятница 2В")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 2В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-В класса на понедельник:", reply_markup=markup)
        file = open('понедельник 2В.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 2В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-В класса на вторник:", reply_markup=markup)
        file = open('вторник 2В.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 2В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-В класса на среду:", reply_markup=markup)
        file = open('среда 2В.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 2В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-В класса на четверг:", reply_markup=markup)
        file = open('четверг 2В.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 2В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-В класса на пятницу:", reply_markup=markup)
        file = open('пятница 2В.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)


    elif (message.text == "2Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 2Г")
        btn2 = types.KeyboardButton("Вторник 2Г")
        btn3 = types.KeyboardButton("Среда 2Г")
        btn4 = types.KeyboardButton("Четверг 2Г")
        btn5 = types.KeyboardButton("Пятница 2Г")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 2Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-Г класса на понедельник:", reply_markup=markup)
        file = open('понедельник 2Г.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 2Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-Г класса на вторник:", reply_markup=markup)
        file = open('вторник 2Г.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 2Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-Г класса на среду:", reply_markup=markup)
        file = open('среда 2Г.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 2Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-Г класса на четверг:", reply_markup=markup)
        file = open('четверг 2Г.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 2Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-Г класса на пятницу:", reply_markup=markup)
        file = open('пятница 2Г.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "2Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 2Д")
        btn2 = types.KeyboardButton("Вторник 2Д")
        btn3 = types.KeyboardButton("Среда 2Д")
        btn4 = types.KeyboardButton("Четверг 2Д")
        btn5 = types.KeyboardButton("Пятница 2Д")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 2Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-Д класса на понедельник:", reply_markup=markup)
        file = open('понедельник 2Д.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 2Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-Д класса на вторник:", reply_markup=markup)
        file = open('вторник 2Д.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 2Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-Д класса на среду:", reply_markup=markup)
        file = open('среда 2Д.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 2Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-Д класса на четверг:", reply_markup=markup)
        file = open('четверг 2Д.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 2Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-Д класса на пятницу:", reply_markup=markup)
        file = open('пятница 2Д.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "2Е"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 2Е")
        btn2 = types.KeyboardButton("Вторник 2Е")
        btn3 = types.KeyboardButton("Среда 2Е")
        btn4 = types.KeyboardButton("Четверг 2Е")
        btn5 = types.KeyboardButton("Пятница 2Е")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 2Е"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-Е класса на понедельник:", reply_markup=markup)
        file = open('понедельник 2Е.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 2Е"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-Е класса на вторник:", reply_markup=markup)
        file = open('вторник 2Е.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 2Е"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-Е класса на среду:", reply_markup=markup)
        file = open('среда 2Е.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 2Е"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-Е класса на четверг:", reply_markup=markup)
        file = open('четверг 2Е.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 2Е"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 2-Е класса на пятницу:", reply_markup=markup)
        file = open('пятница 2Е.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "3 класс"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("3А")
        btn2 = types.KeyboardButton("3Б")
        btn3 = types.KeyboardButton("3В")
        btn4 = types.KeyboardButton("3Г")
        btn5 = types.KeyboardButton("3Д")
        btn6 = types.KeyboardButton("3Е")
        markup.row(btn1, btn2, btn3)
        markup.row(btn4, btn5, btn6)
        btn5 = types.KeyboardButton("Вернуться назад")
        markup.row(btn5)
        bot.send_message(message.chat.id, text="Выбери букву:", reply_markup=markup)

    elif (message.text == "3А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 3А")
        btn2 = types.KeyboardButton("Вторник 3А")
        btn3 = types.KeyboardButton("Среда 3А")
        btn4 = types.KeyboardButton("Четверг 3А")
        btn5 = types.KeyboardButton("Пятница 3А")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 3А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-А класса на понедельник:", reply_markup=markup)
        file = open('понедельник 3А.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 3А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-А класса на вторник:", reply_markup=markup)
        file = open('вторник3А.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 3А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-А класса на среду:", reply_markup=markup)
        file = open('среда 3А.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 3А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-А класса на четверг:", reply_markup=markup)
        file = open('четверг 3А.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 3А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-А класса на пятницу:", reply_markup=markup)
        file = open('Пятница 3А.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "3Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 3Б")
        btn2 = types.KeyboardButton("Вторник 3Б")
        btn3 = types.KeyboardButton("Среда 3Б")
        btn4 = types.KeyboardButton("Четверг 3Б")
        btn5 = types.KeyboardButton("Пятница 3Б")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 3Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-Б класса на понедельник:", reply_markup=markup)
        file = open('понедельник 3Б.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 3Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-Б класса на вторник:", reply_markup=markup)
        file = open('вторник 3Б.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 3Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-Б класса на среду:", reply_markup=markup)
        file = open('среда 3Б.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 3Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-Б класса на четверг:", reply_markup=markup)
        file = open('четверг 3Б.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 3Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-Б класса на пятницу:", reply_markup=markup)
        file = open('пятница 3Б.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "3В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 3В")
        btn2 = types.KeyboardButton("Вторник 3В")
        btn3 = types.KeyboardButton("Среда 3В")
        btn4 = types.KeyboardButton("Четверг 3В")
        btn5 = types.KeyboardButton("Пятница 3В")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 3В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-В класса на понедельник:", reply_markup=markup)
        file = open('понедельник 3В.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 3В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-В класса на вторник:", reply_markup=markup)
        file = open('вторник 3В.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 3В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-В класса на среду:", reply_markup=markup)
        file = open('среда 3В.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 3В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-В класса на четверг:", reply_markup=markup)
        file = open('четверг 3В.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 3В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-В класса на пятницу:", reply_markup=markup)
        file = open('пятница 3В.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)


    elif (message.text == "3Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 3Г")
        btn2 = types.KeyboardButton("Вторник 3Г")
        btn3 = types.KeyboardButton("Среда 3Г")
        btn4 = types.KeyboardButton("Четверг 3Г")
        btn5 = types.KeyboardButton("Пятница 3Г")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 3Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-Г класса на понедельник:", reply_markup=markup)
        file = open('понедельник 3Г.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 3Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-Г класса на вторник:", reply_markup=markup)
        file = open('вторник 3Г.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 3Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-Г класса на среду:", reply_markup=markup)
        file = open('среда 3Г.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 3Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-Г класса на четверг:", reply_markup=markup)
        file = open('четверг 3Г.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 3Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-Г класса на пятницу:", reply_markup=markup)
        file = open('пятница 3Г.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "3Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 3Д")
        btn2 = types.KeyboardButton("Вторник 3Д")
        btn3 = types.KeyboardButton("Среда 3Д")
        btn4 = types.KeyboardButton("Четверг 3Д")
        btn5 = types.KeyboardButton("Пятница 3Д")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 3Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-Д класса на понедельник:", reply_markup=markup)
        file = open('понедельник 3Д.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 3Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-Д класса на вторник:", reply_markup=markup)
        file = open('вторник 3Д.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 3Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-Д класса на среду:", reply_markup=markup)
        file = open('среда 3Д.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 3Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-Д класса на четверг:", reply_markup=markup)
        file = open('четверг 3Д.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 3Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-Д класса на пятницу:", reply_markup=markup)
        file = open('пятница 3Д.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "3Е"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 3Е")
        btn2 = types.KeyboardButton("Вторник 3Е")
        btn3 = types.KeyboardButton("Среда 3Е")
        btn4 = types.KeyboardButton("Четверг 3Е")
        btn5 = types.KeyboardButton("Пятница 3Е")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 3Е"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-Е класса на понедельник:", reply_markup=markup)
        file = open('понедельник 3Е.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 3Е"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-Е класса на вторник:", reply_markup=markup)
        file = open('вторник 3Е.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 3Е"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-Е класса на среду:", reply_markup=markup)
        file = open('среда 3Е.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 3Е"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-Е класса на четверг:", reply_markup=markup)
        file = open('четверг 3Е.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 3Е"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 3-Е класса на пятницу:", reply_markup=markup)
        file = open('пятница 3Е.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)


    elif (message.text == "4 класс"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("4А")
        btn2 = types.KeyboardButton("4Б")
        btn3 = types.KeyboardButton("4В")
        btn4 = types.KeyboardButton("4Г")
        btn5 = types.KeyboardButton("4Д")
        markup.row(btn1, btn2)
        markup.row(btn3, btn4, btn5)
        btn5 = types.KeyboardButton("Вернуться назад")
        markup.row(btn5)
        bot.send_message(message.chat.id, text="Выбери букву:", reply_markup=markup)

    elif (message.text == "4А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 4А")
        btn2 = types.KeyboardButton("Вторник 4А")
        btn3 = types.KeyboardButton("Среда 4А")
        btn4 = types.KeyboardButton("Четверг 4А")
        btn5 = types.KeyboardButton("Пятница 4А")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 4А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-А класса на понедельник:", reply_markup=markup)
        file = open('понедельник 4А.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 4А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-А класса на вторник:", reply_markup=markup)
        file = open('вторник 4А.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 4А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-А класса на среду:", reply_markup=markup)
        file = open('среда 4А.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 4А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-А класса на четверг:", reply_markup=markup)
        file = open('четверг 4А.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 4А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-А класса на пятницу:", reply_markup=markup)
        file = open('пятница 4А.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "4Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 4Б")
        btn2 = types.KeyboardButton("Вторник 4Б")
        btn3 = types.KeyboardButton("Среда 4Б")
        btn4 = types.KeyboardButton("Четверг 4Б")
        btn5 = types.KeyboardButton("Пятница 4Б")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 4Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-Б класса на понедельник:", reply_markup=markup)
        file = open('понедельник 4Б.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 4Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-Б класса на вторник:", reply_markup=markup)
        file = open('вторник 4Б.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 4Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-Б класса на среду:", reply_markup=markup)
        file = open('среда 4Б.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 4Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-Б класса на четверг:", reply_markup=markup)
        file = open('четверг 4Б.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 4Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-Б класса на пятницу:", reply_markup=markup)
        file = open('пятница 4Б.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "4В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 4В")
        btn2 = types.KeyboardButton("Вторник 4В")
        btn3 = types.KeyboardButton("Среда 4В")
        btn4 = types.KeyboardButton("Четверг 4В")
        btn5 = types.KeyboardButton("Пятница 4В")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 4В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-В класса на понедельник:", reply_markup=markup)
        file = open('понедельник 4В.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 4В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-В класса на вторник:", reply_markup=markup)
        file = open('вторник 4В.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 4В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-В класса на среду:", reply_markup=markup)
        file = open('среда 4В.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 4В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-В класса на четверг:", reply_markup=markup)
        file = open('четверг 4В.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 4В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-В класса на пятницу:", reply_markup=markup)
        file = open('пятница 4В.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)


    elif (message.text == "4Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 4Г")
        btn2 = types.KeyboardButton("Вторник 4Г")
        btn3 = types.KeyboardButton("Среда 4Г")
        btn4 = types.KeyboardButton("Четверг 4Г")
        btn5 = types.KeyboardButton("Пятница 4Г")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 4Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-Г класса на понедельник:", reply_markup=markup)
        file = open('понедельник 4Г.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 4Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-Г класса на вторник:", reply_markup=markup)
        file = open('вторник 4Г.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 4Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-Г класса на среду:", reply_markup=markup)
        file = open('среда 4Г.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 4Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-Г класса на четверг:", reply_markup=markup)
        file = open('четверг 4Г.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 4Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-Г класса на пятницу:", reply_markup=markup)
        file = open('пятница 4Г.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "4Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 4Д")
        btn2 = types.KeyboardButton("Вторник 4Д")
        btn3 = types.KeyboardButton("Среда 4Д")
        btn4 = types.KeyboardButton("Четверг 4Д")
        btn5 = types.KeyboardButton("Пятница 4Д")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 4Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-Д класса на понедельник:", reply_markup=markup)
        file = open('понедельник 4Д.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 4Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-Д класса на вторник:", reply_markup=markup)
        file = open('вторник 4Д.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 4Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-Д класса на среду:", reply_markup=markup)
        file = open('среда 4Д.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 4Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-Д класса на четверг:", reply_markup=markup)
        file = open('четверг 4Д.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 4Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 4-Д класса на пятницу:", reply_markup=markup)
        file = open('пятница 4Д.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Средняя школа"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("5 класс")
        btn2 = types.KeyboardButton("6 класс")
        btn3 = types.KeyboardButton("7 класс")
        markup.row(btn1, btn2, btn3)
        btn4 = types.KeyboardButton("8 класс")
        btn5 = types.KeyboardButton("9 класс")
        markup.row( btn4, btn5)
        btn6 = types.KeyboardButton("Вернуться назад")
        markup.row(btn6)
        bot.send_message(message.chat.id, text="Выбери класс:", reply_markup=markup)

    elif (message.text == "5 класс"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("5А")
        btn2 = types.KeyboardButton("5Б")
        btn3 = types.KeyboardButton("5В")
        markup.row(btn1, btn2, btn3)
        btn5 = types.KeyboardButton("Вернуться назад")
        markup.row(btn5)
        bot.send_message(message.chat.id, text="Выбери букву:", reply_markup=markup)

    elif (message.text == "5А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 5А")
        btn2 = types.KeyboardButton("Вторник 5А")
        btn3 = types.KeyboardButton("Среда 5А")
        btn4 = types.KeyboardButton("Четверг 5А")
        btn5 = types.KeyboardButton("Пятница 5А")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 5А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 5-А класса на понедельник:", reply_markup=markup)
        file = open('5а понедельник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 5А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 5-А класса на вторник:", reply_markup=markup)
        file = open('5а вторник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 5А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 5-А класса на среду:", reply_markup=markup)
        file = open('5а среда.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 5А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 5-А класса на четверг:", reply_markup=markup)
        file = open('5а четверг.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 5А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 5-А класса на пятницу:", reply_markup=markup)
        file = open('5а пятница.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "5Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 5Б")
        btn2 = types.KeyboardButton("Вторник 5Б")
        btn3 = types.KeyboardButton("Среда 5Б")
        btn4 = types.KeyboardButton("Четверг 5Б")
        btn5 = types.KeyboardButton("Пятница 5Б")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 5Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 5-Б класса на понедельник:", reply_markup=markup)
        file = open('5б понедельник .png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 5Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 5-Б класса на вторник:", reply_markup=markup)
        file = open('5б вторник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 5Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 5-Б класса на среду:", reply_markup=markup)
        file = open('5б среда.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 5Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 5-Б класса на четверг:", reply_markup=markup)
        file = open('5б четверг.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 5Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 5-Б класса на пятницу:", reply_markup=markup)
        file = open('5б пятница.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "5В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 5В")
        btn2 = types.KeyboardButton("Вторник 5В")
        btn3 = types.KeyboardButton("Среда 5В")
        btn4 = types.KeyboardButton("Четверг 5В")
        btn5 = types.KeyboardButton("Пятница 5В")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 5В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 5-В класса на понедельник:", reply_markup=markup)
        file = open('5в понедельник .png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 5В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 5-В класса на вторник:", reply_markup=markup)
        file = open('5в вторник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 5В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 5-В класса на среду:", reply_markup=markup)
        file = open('5в среда.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 5В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 5-В класса на четверг:", reply_markup=markup)
        file = open('5в четверг.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 5В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 5-В класса на пятницу:", reply_markup=markup)
        file = open('5в пятница.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)



    elif (message.text == "6 класс"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("6А")
        btn2 = types.KeyboardButton("6Б")
        btn3 = types.KeyboardButton("6С")
        markup.row(btn1, btn2, btn3)
        btn5 = types.KeyboardButton("Вернуться назад")
        markup.row(btn5)
        bot.send_message(message.chat.id, text="Выбери букву:", reply_markup=markup)

    elif (message.text == "6А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 6А")
        btn2 = types.KeyboardButton("Вторник 6А")
        btn3 = types.KeyboardButton("Среда 6А")
        btn4 = types.KeyboardButton("Четверг 6А")
        btn5 = types.KeyboardButton("Пятница 6А")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 6А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 6-А класса на понедельник:", reply_markup=markup)
        file = open('6а понедельник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 6А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 6-А класса на вторник:", reply_markup=markup)
        file = open('6а вторник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 6А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 6-А класса на среду:", reply_markup=markup)
        file = open('6а среда.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 6А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 6-А класса на четверг:", reply_markup=markup)
        file = open('6а четверг.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 6А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 6-А класса на пятницу:", reply_markup=markup)
        file = open('6а пятница.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "6Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 6Б")
        btn2 = types.KeyboardButton("Вторник 6Б")
        btn3 = types.KeyboardButton("Среда 6Б")
        btn4 = types.KeyboardButton("Четверг 6Б")
        btn5 = types.KeyboardButton("Пятница 6Б")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 6Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 6-Б класса на понедельник:", reply_markup=markup)
        file = open('6б понедельник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)


    elif (message.text == "Вторник 6Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 6-Б класса на вторник:", reply_markup=markup)
        file = open('6б вторник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 6Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 6-Б класса на среду:", reply_markup=markup)
        file = open('6б среда.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 6Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 6-Б класса на четверг:", reply_markup=markup)
        file = open('6б четверг.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 6Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 6-Б класса на пятницу:", reply_markup=markup)
        file = open('6б пятница.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "6С"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 6С")
        btn2 = types.KeyboardButton("Вторник 6С")
        btn3 = types.KeyboardButton("Среда 6С")
        btn4 = types.KeyboardButton("Четверг 6С")
        btn5 = types.KeyboardButton("Пятница 6С")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 6С"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 6-С класса на понедельник:", reply_markup=markup)
        file = open('6с понедельник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 6С"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 6-С класса на вторник:", reply_markup=markup)
        file = open('6с вторник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 6С"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 6-С класса на среду:", reply_markup=markup)
        file = open('6с среда.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 6С"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 6-С класса на четверг:", reply_markup=markup)
        file = open('6с четверг.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 6С"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 6-С класса на пятницу:", reply_markup=markup)
        file = open('6с пятница.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)


    elif (message.text == "7 класс"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("7А")
        btn2 = types.KeyboardButton("7Б")
        markup.row(btn1, btn2)
        btn5 = types.KeyboardButton("Вернуться назад")
        markup.row(btn5)
        bot.send_message(message.chat.id, text="Выбери букву:", reply_markup=markup)

    elif (message.text == "7А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 7А")
        btn2 = types.KeyboardButton("Вторник 7А")
        btn3 = types.KeyboardButton("Среда 7А")
        btn4 = types.KeyboardButton("Четверг 7А")
        btn5 = types.KeyboardButton("Пятница 7А")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 7А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 7-А класса на понедельник:", reply_markup=markup)
        file = open('7а понедельник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 7А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 7-А класса на вторник:", reply_markup=markup)
        file = open('7а вторник 2.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 7А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 7-А класса на среду:", reply_markup=markup)
        file = open('7а среда.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 7А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 7-А класса на четверг:", reply_markup=markup)
        file = open('7а четверг.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 7А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 7-А класса на пятницу:", reply_markup=markup)
        file = open('7а пятница.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "7Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 7Б")
        btn2 = types.KeyboardButton("Вторник 7Б")
        btn3 = types.KeyboardButton("Среда 7Б")
        btn4 = types.KeyboardButton("Четверг 7Б")
        btn5 = types.KeyboardButton("Пятница 7Б")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 7Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 7-Б класса на понедельник:", reply_markup=markup)
        file = open('7б понедельник 2.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 7Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 7-Б класса на вторник:", reply_markup=markup)
        file = open('7б вторник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 7Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 7-Б класса на среду:", reply_markup=markup)
        file = open('7б среда.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 7Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 7-Б класса на четверг:", reply_markup=markup)
        file = open('7б четверг.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 7Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 7-Б класса на пятницу:", reply_markup=markup)
        file = open('7б пятница.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)


    elif (message.text == "8 класс"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("8А")
        btn2 = types.KeyboardButton("8Б")
        btn3 = types.KeyboardButton("8В")
        markup.row(btn1, btn2, btn3)
        btn4 = types.KeyboardButton("8Г")
        btn5 = types.KeyboardButton("8Д")
        markup.row(btn4, btn5)
        btn6 = types.KeyboardButton("Вернуться назад")
        markup.row(btn6)
        bot.send_message(message.chat.id, text="Выбери букву:", reply_markup=markup)

    elif (message.text == "8А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 8А")
        btn2 = types.KeyboardButton("Вторник 8А")
        btn3 = types.KeyboardButton("Среда 8А")
        btn4 = types.KeyboardButton("Четверг 8А")
        btn5 = types.KeyboardButton("Пятница 8А")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 8А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-А класса на понедельник:", reply_markup=markup)
        file = open('8а понедельник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 8А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-А класса на вторник:", reply_markup=markup)
        file = open('8а вторник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 8А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-А класса на среду:", reply_markup=markup)
        file = open('8а среда.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 8А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-А класса на четверг:", reply_markup=markup)
        file = open('8а четверг.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 8А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-А класса на пятницу:", reply_markup=markup)
        file = open('8а пятница.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "8Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 8Б")
        btn2 = types.KeyboardButton("Вторник 8Б")
        btn3 = types.KeyboardButton("Среда 8Б")
        btn4 = types.KeyboardButton("Четверг 8Б")
        btn5 = types.KeyboardButton("Пятница 8Б")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 8Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-Б класса на понедельник:", reply_markup=markup)
        file = open('./8б понедельник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 8Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-Б класса на вторник:", reply_markup=markup)
        file = open('8б вторник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 8Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-Б класса на среду:", reply_markup=markup)
        file = open('8б среда.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 8Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-Б класса на четверг:", reply_markup=markup)
        file = open('8б четверг.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 8Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-Б класса на пятницу:", reply_markup=markup)
        file = open('8б пятница.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "8В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 8В")
        btn2 = types.KeyboardButton("Вторник 8В")
        btn3 = types.KeyboardButton("Среда 8В")
        btn4 = types.KeyboardButton("Четверг 8В")
        btn5 = types.KeyboardButton("Пятница 8В")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 8В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-В класса на понедельник:", reply_markup=markup)
        file = open('8в понедельник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 8В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-В класса на вторник:", reply_markup=markup)
        file = open('8в вторник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 8В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-В класса на среду:", reply_markup=markup)
        file = open('8в среда.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 8В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-В класса на четверг:", reply_markup=markup)
        file = open('8в четверг.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 8В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-В класса на пятницу:", reply_markup=markup)
        file = open('8в пятница.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)


    elif (message.text == "8Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 8Г")
        btn2 = types.KeyboardButton("Вторник 8Г")
        btn3 = types.KeyboardButton("Среда 8Г")
        btn4 = types.KeyboardButton("Четверг 8Г")
        btn5 = types.KeyboardButton("Пятница 8Г")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 8Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-Г класса на понедельник:", reply_markup=markup)
        file = open('8г понедельник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 8Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-Г класса на вторник:", reply_markup=markup)
        file = open('8г вторник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 8Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-Г класса на среду:", reply_markup=markup)
        file = open('8г среда.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 8Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-Г класса на четверг:", reply_markup=markup)
        file = open('8г четверг.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 8Г"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-Г класса на пятницу:", reply_markup=markup)
        file = open('8г пятница.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "8Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 8Д")
        btn2 = types.KeyboardButton("Вторник 8Д")
        btn3 = types.KeyboardButton("Среда 8Д")
        btn4 = types.KeyboardButton("Четверг 8Д")
        btn5 = types.KeyboardButton("Пятница 8Д")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 8Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-Д класса на понедельник:", reply_markup=markup)
        file = open('8д понедельник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 8Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-Д класса на вторник:", reply_markup=markup)
        file = open('8д вторник .png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 8Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-Д класса на среду:", reply_markup=markup)
        file = open('8д среда.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 8Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-Д класса на четверг:", reply_markup=markup)
        file = open('8д четверг.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 8Д"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 8-Д класса на пятницу:", reply_markup=markup)
        file = open('8д пятница.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "9 класс"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("9А")
        btn2 = types.KeyboardButton("9Б")
        btn3 = types.KeyboardButton("9В")
        markup.row(btn1, btn2, btn3)
        btn4 = types.KeyboardButton("Вернуться назад")
        markup.row(btn4)
        bot.send_message(message.chat.id, text="Выбери букву:", reply_markup=markup)

    elif (message.text == "9А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 9А")
        btn2 = types.KeyboardButton("Вторник 9А")
        btn3 = types.KeyboardButton("Среда 9А")
        btn4 = types.KeyboardButton("Четверг 9А")
        btn5 = types.KeyboardButton("Пятница 9А")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 9А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 9-А класса на понедельник:", reply_markup=markup)
        file = open('./9а понедельник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 9А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 9-А класса на вторник:", reply_markup=markup)
        file = open('9а вторник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 9А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 9-А класса на среду:", reply_markup=markup)
        file = open('9 а среда.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 9А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 9-А класса на четверг:", reply_markup=markup)
        file = open('9а четверг.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 9А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 9-А класса на пятницу:", reply_markup=markup)
        file = open('9а пятница.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "9Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 9Б")
        btn2 = types.KeyboardButton("Вторник 9Б")
        btn3 = types.KeyboardButton("Среда 9Б")
        btn4 = types.KeyboardButton("Четверг 9Б")
        btn5 = types.KeyboardButton("Пятница 9Б")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 9Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 9-Б класса на понедельник:", reply_markup=markup)
        file = open('9б понедельник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 9Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 9-Б класса на вторник:", reply_markup=markup)
        file = open('9б вторник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 9Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 9-Б класса на среду:", reply_markup=markup)
        file = open('9б среда.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 9Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 9-Б класса на четверг:", reply_markup=markup)
        file = open('9б четверг.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 9Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 9-Б класса на пятницу:", reply_markup=markup)
        file = open('9б пятница.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "9В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 9В")
        btn2 = types.KeyboardButton("Вторник 9В")
        btn3 = types.KeyboardButton("Среда 9В")
        btn4 = types.KeyboardButton("Четверг 9В")
        btn5 = types.KeyboardButton("Пятница 9В")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 9В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 9-В класса на понедельник:", reply_markup=markup)
        file = open('9в понедельник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 9В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 9-В класса на вторник:", reply_markup=markup)
        file = open('9в вторник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 9В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 9-В класса на среду:", reply_markup=markup)
        file = open('9в среда.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 9В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 9-В класса на четверг:", reply_markup=markup)
        file = open('9 в четверг.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 9В"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 9-В класса на пятницу:", reply_markup=markup)
        file = open('9 в пятница.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Старшая школа"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("10 класс")
        btn2 = types.KeyboardButton("11 класс")
        markup.row(btn1, btn2)
        btn5 = types.KeyboardButton("Вернуться назад")
        markup.row(btn5)
        bot.send_message(message.chat.id, text="Выбери класс:", reply_markup=markup)

    elif (message.text == "10 класс"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("10А")
        btn2 = types.KeyboardButton("10Б")
        markup.row(btn1, btn2)
        btn5 = types.KeyboardButton("Вернуться назад")
        markup.row(btn5)
        bot.send_message(message.chat.id, text="Выбери букву:", reply_markup=markup)

    elif (message.text == "10А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 10А")
        btn2 = types.KeyboardButton("Вторник 10А")
        btn3 = types.KeyboardButton("Среда 10А")
        btn4 = types.KeyboardButton("Четверг 10А")
        btn5 = types.KeyboardButton("Пятница 10А")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 10А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.InlineKeyboardButton("Вернуться назад", callback_data='delete')
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 10-А класса на понедельник:", reply_markup=markup)
        file = open('10 а понедельник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 10А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 10-А класса на вторник:", reply_markup=markup)
        file = open('10 а вторник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 10А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 10-А класса на среду:", reply_markup=markup)
        file = open('10 а среда.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 10А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 10-А класса на четверг:", reply_markup=markup)
        file = open('10 а четверг.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 10А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 10-А класса на пятницу:", reply_markup=markup)
        file = open('10 а пятница.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "10Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 10Б")
        btn2 = types.KeyboardButton("Вторник 10Б")
        btn3 = types.KeyboardButton("Среда 10Б")
        btn4 = types.KeyboardButton("Четверг 10Б")
        btn5 = types.KeyboardButton("Пятница 10Б")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 10Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 10-Б класса на понедельник:", reply_markup=markup)
        file = open('10 б  понедельник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 10Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 10-Б класса на вторник:", reply_markup=markup)
        file = open('10 б вторник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 10Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 10-Б класса на среду:", reply_markup=markup)
        file = open('10 б среда.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 10Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 10-Б класса на четверг:", reply_markup=markup)
        file = open('10 б четверг.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 10Б"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 10-Б класса на пятницу:", reply_markup=markup)
        file = open('10 б пятница.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)


    elif (message.text == "11 класс"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("11А")
        markup.row(btn1)
        btn5 = types.KeyboardButton("Вернуться назад")
        markup.row(btn5)
        bot.send_message(message.chat.id, text="Выбери букву:", reply_markup=markup)

    elif (message.text == "11А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Понедельник 11А")
        btn2 = types.KeyboardButton("Вторник 11А")
        btn3 = types.KeyboardButton("Среда 11А")
        btn4 = types.KeyboardButton("Четверг 11А")
        btn5 = types.KeyboardButton("Пятница 11А")
        markup.add(btn1, btn2, btn3, btn4, btn5)
        bot.send_message(message.chat.id, text="Выбери день недели:", reply_markup=markup)

    elif (message.text == "Понедельник 11А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 11-А класса на понедельник:", reply_markup=markup)
        file = open('11 а понедельник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Вторник 11А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 11-А класса на вторник:", reply_markup=markup)
        file = open('11 а вторник.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Среда 11А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 11-А класса на среду:", reply_markup=markup)
        file = open('11 а среда.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Четверг 11А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 11-А класса на четверг:", reply_markup=markup)
        file = open('11 а четверг.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == "Пятница 11А"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        btn1 = types.KeyboardButton("Вернуться назад")
        markup.add(btn1)
        bot.send_message(message.chat.id, text="Расписание 11-А класса на пятницу:", reply_markup=markup)
        file = open('11 а пятница.png', 'rb')
        bot.send_photo(message.chat.id, file, reply_markup=markup)

    elif (message.text == 'Вернуться назад'):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        button1 = types.KeyboardButton("Расписание уроков")
        button2 = types.KeyboardButton("Расписание звонков")
        markup.add(button1, button2)
        bot.send_message(message.chat.id, text="Вы вернулись в главное меню", reply_markup=markup)


    elif (message.text == "Вернуться в главное меню"):
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        button1 = types.KeyboardButton("Расписание уроков")
        button2 = types.KeyboardButton("Расписание звонков")
        markup.add(button1, button2)
        bot.send_message(message.chat.id, text="Вы вернулись в главное меню", reply_markup=markup)
    else:
        bot.send_message(message.chat.id, text="Попробуйте еще раз...")



bot.polling(none_stop = True)

